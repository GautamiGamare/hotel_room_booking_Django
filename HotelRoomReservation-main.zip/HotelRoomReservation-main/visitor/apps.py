from django.apps import AppConfig


class VisitorConfig(AppConfig):
    name = 'visitor'
