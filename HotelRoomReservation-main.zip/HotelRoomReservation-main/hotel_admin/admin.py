from django.contrib import admin
# from hotel_admin.models import roomType,roomImages,hotelRooms
#
# admin.site.register(roomType),
# admin.site.register(roomImages),
# admin.site.register(hotelRooms),
