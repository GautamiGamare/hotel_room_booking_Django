from django.apps import AppConfig


class HotelAdminConfig(AppConfig):
    name = 'hotel_admin'
