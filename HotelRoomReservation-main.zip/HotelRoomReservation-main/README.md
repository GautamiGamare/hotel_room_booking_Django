# HotelRoomReservation

# UserModel :
  In this project user can book hotel room by choosing type of room and Providing checking and checkout date and number of guests. According to number of guests, number of rooms atomatically will be displayed using jquery.If room is available user can book the room. Later if he/she want to cancel it then they can cancel the room.
For booking the room user must login. Already registered user can directly login. If user is not register then he/she have to register first. I stored user passwords in encrypted format. For storing the data I used Mysql database.
# AdminModel :
  In admin model, Admin first need to login. Admin can add new room type and room details like facilities, capacity, number of beds. Admin can add new roomid of perticular room type, can add new images of perticular types. Admin can view reports like, to check one perticular date booking or booking from and to date, booking of perticular user, booking or perticular room type.
  
